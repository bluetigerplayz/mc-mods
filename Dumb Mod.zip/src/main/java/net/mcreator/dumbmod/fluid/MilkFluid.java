
package net.mcreator.dumbmod.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ParticleOptions;

import net.mcreator.dumbmod.init.DumbModModItems;
import net.mcreator.dumbmod.init.DumbModModFluids;
import net.mcreator.dumbmod.init.DumbModModFluidTypes;
import net.mcreator.dumbmod.init.DumbModModBlocks;

public abstract class MilkFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> DumbModModFluidTypes.MILK_TYPE.get(), () -> DumbModModFluids.MILK.get(), () -> DumbModModFluids.FLOWING_MILK.get()).explosionResistance(100f)
			.tickRate(69).bucket(() -> DumbModModItems.MILK_BUCKET.get()).block(() -> (LiquidBlock) DumbModModBlocks.MILK.get());

	private MilkFluid() {
		super(PROPERTIES);
	}

	@Override
	public ParticleOptions getDripParticle() {
		return ParticleTypes.EXPLOSION;
	}

	public static class Source extends MilkFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends MilkFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
