
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.dumbmod.init;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;

public class DumbModModTabs {
	public static CreativeModeTab TAB_BT;

	public static void load() {
		TAB_BT = new CreativeModeTab("tabbt") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(Blocks.RAW_GOLD_BLOCK);
			}

			@Override
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
}
