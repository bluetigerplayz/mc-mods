
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.dumbmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fluids.FluidType;

import net.mcreator.dumbmod.fluid.types.MilkFluidType;
import net.mcreator.dumbmod.DumbModMod;

public class DumbModModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(ForgeRegistries.Keys.FLUID_TYPES, DumbModMod.MODID);
	public static final RegistryObject<FluidType> MILK_TYPE = REGISTRY.register("milk", () -> new MilkFluidType());
}
