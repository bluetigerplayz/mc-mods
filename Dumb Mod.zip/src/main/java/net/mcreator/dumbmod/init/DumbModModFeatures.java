
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.dumbmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.levelgen.feature.Feature;

import net.mcreator.dumbmod.world.features.MilkFeatureFeature;
import net.mcreator.dumbmod.DumbModMod;

@Mod.EventBusSubscriber
public class DumbModModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.FEATURES, DumbModMod.MODID);
	public static final RegistryObject<Feature<?>> MILK_FEATURE = REGISTRY.register("milk_feature", MilkFeatureFeature::new);
}
