
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.dumbmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.dumbmod.block.MilkBlockBlock;
import net.mcreator.dumbmod.block.MilkBlock;
import net.mcreator.dumbmod.block.CheeseDimentionPortalBlock;
import net.mcreator.dumbmod.block.CheeseBlock;
import net.mcreator.dumbmod.DumbModMod;

public class DumbModModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, DumbModMod.MODID);
	public static final RegistryObject<Block> CHEESE = REGISTRY.register("cheese", () -> new CheeseBlock());
	public static final RegistryObject<Block> CHEESE_DIMENTION_PORTAL = REGISTRY.register("cheese_dimention_portal", () -> new CheeseDimentionPortalBlock());
	public static final RegistryObject<Block> MILK = REGISTRY.register("milk", () -> new MilkBlock());
	public static final RegistryObject<Block> MILK_BLOCK = REGISTRY.register("milk_block", () -> new MilkBlockBlock());
}
